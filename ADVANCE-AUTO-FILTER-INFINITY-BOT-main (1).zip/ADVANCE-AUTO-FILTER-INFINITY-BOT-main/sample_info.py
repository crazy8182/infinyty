# Bot information
SESSION = 'Media_search'
USER_SESSION = 'User_Bot'
API_ID = 21938068
API_HASH = 'c18fd98f3e58484df0aecd95a3d5a6a9'
BOT_TOKEN = '6612163922:AAGGjN0bJZfIgiGVDW9No82ZI4N7Dgza0aM'
USERBOT_STRING_SESSION = ''

# Bot settings
CACHE_TIME = 300
USE_CAPTION_FILTER = False

# Admins, Channels & Users
ADMINS = [5787509903]
CHANNELS = [-1001984741311]
AUTH_USERS = [5787509903]
AUTH_CHANNEL = None

# MongoDB information
DATABASE_URI = "mongodb+srv://krishna527062:yuvraj178@cluster0.bki9yaw.mongodb.net/?retryWrites=true&w=majority"
DATABASE_NAME = 'Krishna527062'
COLLECTION_NAME = 'Telegram_files'  # If you are using the same database, then use different collection name for each bot


